<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>UTS pemrograman framework</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../assets/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-collapse layout-top-nav">
<div class="wrapper">

  <!-- Navbar -->
<nav class="main-header navbar navbar-expand-md navbar-light navbar-white">
    <div class="container">
      <a href="" class="navbar-brand">
        <span class="brand-text font-weight-light">Pemesanan Hotel</span>
      </a>

      <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" 
      aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse order-3" id="navbarCollapse">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
          </li>
          <li class="nav-item">
            <a href="index.php" class="nav-link"> | Dashboard |</a>
          </li>
          <li class="nav-item">
            <a href="kamar.php" class="nav-link"> | Kamar |</a>
          </li>
          <li class="nav-item">
            <a href="fasilitas.php" class="nav-link"> | Fasilitas Kamar |</a>
          </li>
          <li class="nav-item">
            <a href="galeri.php" class="nav-link"> | Galeri |</a>
          </li>
        </ul>
      </div>
    </div>
</nav>
  <!-- /.navbar -->

  <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
        <div class="container">
            <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0"> Fasilitas Kamar </h1>
            </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container">
                <div class="col-md-12">
                    <div class="card card-outline card-info">
                        <div class="card-body">
                            <div class="row">
                                <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th style="width: 300x">No Kamar</th>
                                        <th>Fasilitas</th>
                                        <th style="width: 150px">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1.</td>
                                        <td>TIPE SULTAN</td>
                                        <td>
                                            <p>
                                            WiFi Internet, Kasur King size, Meja makan, Ruang meeting, Ruang keluarga, TV, AC, Meja rias, Kamar mandi (bathtub,shower,spa)
                                            </p>
                                        </td>
                                        <td>
                                            <a href="" class="btn btn btn-warning">Edit</a>
                                            <a href="" class="btn btn btn-danger">Hapus</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2.</td>
                                        <td>TIPE MENENGAH</td>
                                        <td>
                                            <p>
                                            Kasur biasa, Meja makan, Ruang keluarga, AC, Meja rias, Kamar mandi (shower)
                                            </p>
                                        </td>
                                        <td>
                                            <a href="" class="btn btn btn-warning">Edit</a>
                                            <a href="" class="btn btn btn-danger">Hapus</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>3.</td>
                                        <td>TIPE STANDAR</td>
                                        <td>
                                            <p>
                                            Kasur biasa, AC, Kamar mandi
                                            </p>
                                        </td>
                                        <td>
                                            <a href="" class="btn btn btn-warning">Edit</a>
                                            <a href="" class="btn btn btn-danger">Hapus</a>
                                        </td>
                                    </tr>
                                </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </div>
        </div>
    </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
  <!-- /.control-sidebar -->

<!-- jQuery -->
<script src="../assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../assets/dist/js/adminlte.min.js"></script>
</body>
</html>